package forRuning;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class MainPanel extends JPanel {

	public static int WIDTH = 20, HEIGHT = 10, TOTAL = 200;
	public static byte[] box_er_value = new byte[TOTAL];
	public static boolean showGrid = true;
	public static int LEN = 20;

	public static int nx, ny;
	public static int position = 0;

	public MainPanel() {

		super();
		setBackground(Color.BLACK);
		readyBoxErValue(0);
	}

	public void paintComponent(Graphics g) {

		super.paintComponent(g);

		drawBoxes(g);
		if (showGrid) {
			gridShow(g);
		}

		g.setColor(Color.WHITE);
		// g.fillRect(100, 100, 100, 100);
		int z = 550;
		g.drawString(String.valueOf(nx), z, 50);
		g.drawString(String.valueOf(ny), z, 80);

		position = ny * WIDTH + nx;
		g.drawString(String.valueOf(position), z, 120);

	}

	private void gridShow(Graphics g) {
		// TODO Auto-generated method stub
		g.setColor(Color.RED);

		for (int i = 0; i < HEIGHT; i++) {
			for (int j = 0; j < WIDTH; j++) {
				g.drawRect(j * LEN, i * LEN, LEN, LEN);
			}
		}
	}

	private void drawBoxes(Graphics g) {
		// TODO Auto-generated method stub

		Color color = new Color(0);
		for (int i = 0; i < HEIGHT; i++) {
			for (int j = 0; j < WIDTH; j++) {
				int pos = i * WIDTH + j;

				switch (box_er_value[pos]) {
				case -1:
					color = Color.WHITE;
					break;
				case 0:
					color = Color.BLACK;
					break;
				case 1:
					color = Color.BLUE;
					break;
				case 2:
					color = Color.RED;
					break;
				case 3:
					color = Color.DARK_GRAY;
					break;
				case 4:
					color = Color.lightGray;
					break;
				default:
					color = Color.CYAN;
					break;
				}
				g.setColor(color);
				g.fillRect(j * LEN, i * LEN, LEN, LEN);
			}
		}

	}

	private void readyBoxErValue(int forLevel) {

		for (int i = 0; i < TOTAL; i++)
			box_er_value[i] = 0;

	}

}
