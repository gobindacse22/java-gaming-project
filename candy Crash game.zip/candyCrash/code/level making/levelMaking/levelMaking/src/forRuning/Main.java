package forRuning;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Formatter;

import javax.swing.JFrame;

import org.omg.CosNaming._BindingIteratorImplBase;

public class Main {

	private static String fileName = new String(
			"C:\\Users\\gobinda\\Desktop\\1.txt");

	private static File outputFile;
	private static JFrame mainFrame;
	private static MainPanel mainPanel;
	private static int pos = 0;

	public static void main(String[] args) {

		outputFile = new File(fileName);
		if (!outputFile.exists()) {
			try {
				Formatter formatter = new Formatter(outputFile);
				formatter.close();
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		mainFrame = new JFrame();
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		mainFrame.setSize(dim.width - 700, dim.height - 420);

		mainFrame.setVisible(true);
		mainFrame.setResizable(false);
		mainFrame.setLayout(new GridLayout(1, 1));

		mainFrame.setLocationRelativeTo(null);

		mainPanel = new MainPanel();
		mainFrame.add(mainPanel);

		mainFrame.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub

				int n = e.getKeyCode();
				if (n == KeyEvent.VK_SPACE) {
					if (MainPanel.showGrid)
						MainPanel.showGrid = false;
					else
						MainPanel.showGrid = true;
				} else if (n == KeyEvent.VK_ENTER) {

					try {
						Formatter ff = new Formatter(outputFile);
						for (int i = 0; i < MainPanel.TOTAL; i++) {
							ff.format(" %d", MainPanel.box_er_value[i]);
						}
						ff.format("%s", "\n");
						ff.close();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				} else if (n == KeyEvent.VK_0) {
					for (int i = 0; i < MainPanel.TOTAL; i++) {
						MainPanel.box_er_value[i] = 0;
					}
				} else if (n == KeyEvent.VK_1) {
					for (int i = 0; i < MainPanel.TOTAL; i++) {
						MainPanel.box_er_value[i] = 1;
					}
				} else if (n == KeyEvent.VK_2) {
					for (int i = 0; i < MainPanel.TOTAL; i++) {
						MainPanel.box_er_value[i] = 2;
					}
				} else if (n == KeyEvent.VK_3) {
					for (int i = 0; i < MainPanel.TOTAL; i++) {
						MainPanel.box_er_value[i] = 3;
					}
				} else if (n == KeyEvent.VK_4) {
					for (int i = 0; i < MainPanel.TOTAL; i++) {
						MainPanel.box_er_value[i] = 4;
					}
				} else if (n == KeyEvent.VK_9) {
					for (int i = 0; i < MainPanel.TOTAL; i++) {
						MainPanel.box_er_value[i] = -1;
					}
				}
				mainPanel.repaint();
				// System.out.println(MainPanel.gx + "   " + MainPanel.gy);

			}
		});

		mainFrame.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

				int x = e.getX() - 3;
				int y = e.getY() - 24;

				System.out.println(x + "   " + y);
				x /= MainPanel.LEN;
				y /= MainPanel.LEN;

				if (x >= MainPanel.WIDTH || y >= MainPanel.HEIGHT)
					return;
				pos = y * MainPanel.WIDTH + x;

				if (e.getButton() == 1) {
					if (MainPanel.box_er_value[pos] < 4) {
						MainPanel.box_er_value[pos]++;
						mainPanel.repaint();
					}
				} else {
					if (MainPanel.box_er_value[pos] > -1)
						MainPanel.box_er_value[pos]--;
					mainPanel.repaint();
				}

				System.out.println("\n");
				for (int i = 0; i < MainPanel.TOTAL; i++) {
					System.out.print(MainPanel.box_er_value[i]);
				}
				System.out.println("\n\n\n");

			}
		});

		mainFrame.addMouseMotionListener(new MouseMotionListener() {

			@Override
			public void mouseMoved(MouseEvent e) {
				// TODO Auto-generated method stub

				int x = e.getX() - 9;
				int y = e.getY() - 31;

				MainPanel.nx = x / MainPanel.LEN + 1;
				MainPanel.ny = y / MainPanel.LEN + 1;

				mainPanel.repaint();
			}

			@Override
			public void mouseDragged(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});

	}
}
