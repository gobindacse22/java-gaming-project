package forRuning;

import java.io.File;
import java.util.Enumeration;
import java.util.Scanner;

public class Stage {

private static String file1 = new String("resources/level/");
		//private static String file1 = new String("/candy/level/");
	
	public static int TOTAL_LEVEL = 37;

	public static byte[][] lvl = new byte[TOTAL_LEVEL + 1][MainPanel.TOTAL];
	public static int[] moves = new int[TOTAL_LEVEL + 1];

	public static String[] designer = new String[TOTAL_LEVEL + 1];

	public Stage() {

		for (int j = 0; j <= TOTAL_LEVEL; j++) {
			for (int i = 0; i < MainPanel.TOTAL; i++) {
				lvl[j][i] = 0;
			}
		}

		for (int i = 1; i <= TOTAL_LEVEL; i++)
			getlevel(i);

	}

	private static void getlevel(int j) {
		// TODO Auto-generated method stub

		Scanner sc = null;

		try {
			sc = new Scanner(new File(file1 + String.valueOf(j) + ".txt"));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		designer[j] = sc.next();
	    moves[j] = sc.nextByte();

		for (int i = 0; i < MainPanel.TOTAL; i++) {
			lvl[j][i] = sc.nextByte();
		}

	}

}
