package forRuning;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.io.File;
import java.net.URL;
import java.util.Formatter;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JPanel;

import audio.PlaySound;

public class MainPanel extends JPanel {

	public static int WIDTH = 20, HEIGHT = 10, LEN = 50, TOTAL = 200;

	public static int TOTAL_FRUITES = 6;
	public static byte EMPTY_FRUITE_VALUE = 10;
	public static int gx, gy;
	public static int moves;
	public static int coun = 0;
	public static int info_option = 0, quitValue = 0;
	public static int rx = 150, ry = 150;

	public static byte[] box_er_layer_value = new byte[TOTAL];
	public static byte[] box_er_fruit_value = new byte[TOTAL];

	public static boolean showPause, showPlaing, showMap, showInfo;
	public static boolean showFirstOpen, showQuit;
	public static boolean lastTime, lastTimeLast;

	public static Vector<String> infoVector = new Vector<String>();

	public static PlaySound bgSound;
	public static PlaySound foSound;
	public static PlaySound lcSound;
	public static PlaySound goSound;
	public static PlaySound nlSound;
	public static PlaySound rsSound;
	public static PlaySound llSound;

	public MainPanel() {

		super();
		setBackground(Color.BLACK);
		boxErColorValue(Main.Level);
		makeAllFalse();
		showFirstOpen = true;
	}

	public void paintComponent(Graphics g) {

		super.paintComponent(g);

		coun++;
		// System.out.println(coun);

		if (showQuit) {
			designQuitPanel(g);
			return;
		} else if (showFirstOpen) {
			DesignfirstOpen(g);
			ghum(200);
			repaint();
			return;
		} else if (showPause) {
			pausePanelDrawing(g);
		} else if (showMap) {
			mapShow(g);
			showHowManyMovesHave(g);
		} else if (showPlaing) {

			if (fakaPuronNeeded()) {
				drawBoxesWithColorAndFruits(g);
				showHowManyMovesHave(g);
				phakaPuron();
				lastTime = true;
				ghum(180);
				repaint();
				return;
			} else if (lastTime) {
				drawBoxesWithColorAndFruits(g);
				showHowManyMovesHave(g);
				lastTime = false;
				lastTimeLast = true;
				ghum(100);
				repaint();
				return;
			} else if (levelCompleteKina() && !showInfo) {
				drawBoxesWithColorAndFruits(g);
				showHowManyMovesHave(g);
				showInfo = true;
				info_option = 2;
				infoVector.removeAllElements();
				infoVector.addElement("COMPLETE");
				infoVector.addElement("LEVEL " + String.valueOf(Main.Level));
				infoVector.addElement("PRESS ANY KEY");
				infoVector.addElement("FOR NEXT LEVEL");

				bgSound.stopMusic();
				lcSound = new PlaySound("lc.mid", true);

			} else if (gameOverHoiceKina() && !showInfo) {
				drawBoxesWithColorAndFruits(g);
				showHowManyMovesHave(g);
				info_option = 3;
				showInfo = true;
				infoVector.removeAllElements();
				infoVector.addElement("Game Over!");
				infoVector.addElement("YOU HAVE " + "LIFE");
				infoVector.addElement("PRESS ANY KEY");
				infoVector.addElement("FOR PLAY AGAIN");

				goSound = new PlaySound("go.wav");

				// life er value update korbo ewkhane
				// file input output thakbe
			} else if (randomIzationNeeded()) {
				drawBoxesWithColorAndFruits(g);
				showHowManyMovesHave(g);
				showInfo = true;
				info_option = 1;
				infoVector.removeAllElements();
				infoVector.addElement("NO POSSIBLE CHOICE");
				infoVector.addElement("PRESS ANY KEY");
				infoVector.addElement("FOR RANDOMIZATION");

			} else {
				drawBoxesWithColorAndFruits(g);
				showSelectedAll(g);
				showHowManyMovesHave(g);
			}

			drawDesigner(g);

		}

		if (lastTimeLast) {
			lastTimeLast = false;
			ghum(100);
			repaint();

		}

		if (showInfo) {
			informationShowing(g);
		}

	}

	private void drawDesigner(Graphics g) {
		// TODO Auto-generated method stub

		int x = 5;
		int y = Main.SCR_HEIGHT - 10;
		g.setColor(Color.WHITE);
		g.setFont(new Font("Arial", Font.PLAIN, 20));
		g.drawString("Level Designer: " + Stage.designer[Main.Level], x, y);

	}

	private void designQuitPanel(Graphics g) {
		// TODO Auto-generated method stub

		g.setFont(new Font("Arial", Font.BOLD + Font.PLAIN, 40));
		FontMetrics ff = g.getFontMetrics();

		if (quitValue == 0) {
			g.setColor(Color.red);
		} else
			g.setColor(Color.white);

		int x = Main.SCR_WIDTH / 2 - ff.stringWidth("YES") / 2;
		int y = 400;

		g.drawString("YES", x, y);

		if (quitValue == 1) {
			g.setColor(Color.red);
		} else
			g.setColor(Color.white);

		x = Main.SCR_WIDTH / 2 - ff.stringWidth("NO") / 2;
		y = 450;

		g.drawString("NO", x, y);

	}

	private void DesignfirstOpen(Graphics g) {
		// TODO Auto-generated method stub

		g.setColor(Color.WHITE);
		g.setFont(new Font("Arial", Font.BOLD + Font.PLAIN, 30));
		Graphics2D graphics2d = (Graphics2D) g;
		int len = Main.ruleStrings.size();

		int x = 0, y = 0;

		x = rx;
		y = ry;

		for (int i = 0; i < len; i++) {
			String ss = Main.ruleStrings.elementAt(i);
			if (ss.startsWith("@")) {
				for (int j = 2; j < ss.length() - 1; j += 3) {
					try {
						graphics2d.drawImage(Main.photo[Integer.parseInt(ss
								.substring(j, j + 2))], x, y, null);
					} catch (Exception e) {
						// TODO: handle exception
						e.printStackTrace();
					}
					x += 50;
				}
			} else if (ss.startsWith("*")) {
				int a = Integer.parseInt(ss.substring(1, 3));
				g.setFont(new Font("Arial", Font.PLAIN, a));
				g.drawString(ss, x, y);
				g.setFont(new Font("Arial", Font.PLAIN, 30));
				y += a - 40;
			} else {
				g.drawString(ss, x, y);
			}
			x = rx;
			y += 50;

		}

		ry -= 5;
	}

	public void topLevelUpdate() {
		// TODO Auto-generated method stub

		File ff = new File("D:\\candy\\toplevel\\level.txt");

		int v = Main.Level;

		if (v > Stage.TOTAL_LEVEL) {
			v = 0;
		}
		Formatter formatter = null;
		try {
			formatter = new Formatter(ff);
			formatter.format("%s", String.valueOf(v));
			formatter.close();
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	private void showHowManyMovesHave(Graphics g) {
		// TODO Auto-generated method stub

		String sss = new String("MOVES REMAINING - " + String.valueOf(moves));

		if (moves > 1)
			sss += "s";

		g.setColor(Color.WHITE);
		g.setFont(new Font("Arial", Font.BOLD + Font.PLAIN, 35));
		FontMetrics ff = g.getFontMetrics();
		int sx = Main.SCR_WIDTH / 2 - ff.stringWidth(sss) / 2;
		int sy = gy + 10 + (LEN * (HEIGHT + 1));

		g.drawString(sss, sx, sy);

	}

	private boolean gameOverHoiceKina() {
		// TODO Auto-generated method stub

		if (moves <= 0)
			return true;

		return false;
	}

	public void notunLevelStart() {
		Main.Level++;

		if (Main.Level > Stage.TOTAL_LEVEL) {
			makeAllFalse();
			// showPlaing = true;
			showInfo = true;
			info_option = 5;
			infoVector.removeAllElements();
			infoVector.addElement("THIS IS THE LAST LEVEL");
			infoVector.addElement("PRESS ANY KEY");
			infoVector.addElement("TO START LEVEL 1");
			Main.Level = 1;
			topLevelUpdate();
			boxErColorValue(Main.Level);

			llSound = new PlaySound("ll.mid", true);
			return;
		}
		topLevelUpdate();
		boxErColorValue(Main.Level);
		makeAllFalse();
		showPlaing = true;
		showInfo = true;
		info_option = 4;
		infoVector.removeAllElements();
		infoVector.addElement("STARTING");
		infoVector.addElement("LEVEL " + String.valueOf(Main.Level));
		infoVector.addElement("PRESS ANY KEY");

		bgSound = new PlaySound("bg.mid", true);

	}

	public void ghum(int i) {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(i);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private boolean levelCompleteKina() {
		// TODO Auto-generated method stub
		for (int i = 0; i < TOTAL; i++) {
			if (box_er_layer_value[i] > 0)
				return false;
		}
		return true;
	}

	private boolean fakaPuronNeeded() {
		// TODO Auto-generated method stub

		for (int i = 0; i < TOTAL; i++) {
			if (box_er_fruit_value[i] == EMPTY_FRUITE_VALUE) {
				return true;
			}
		}
		return false;
	}

	public void selectRandomLy() {
		// TODO Auto-generated method stub
		Random r = new Random();
		for (int i = 0; i < TOTAL; i++) {
			if (box_er_layer_value[i] != -1 && box_er_layer_value[i] < 3) {
				box_er_fruit_value[i] = (byte) r.nextInt(TOTAL_FRUITES);
			}
		}
		repaint();
	}

	private boolean randomIzationNeeded() {
		// TODO Auto-generated method stub

		for (int i = 0; i < TOTAL; i++) {
			int val = box_er_fruit_value[i];
			if (val != -1 && box_er_layer_value[i] < 3) {
				int cnt = 0;
				if (i >= WIDTH) {
					if (val == box_er_fruit_value[i - WIDTH]
							&& box_er_layer_value[i - WIDTH] < 3)
						cnt++;
				}
				if (i % WIDTH != WIDTH - 1 && box_er_layer_value[i + 1] < 3) {
					if (val == box_er_fruit_value[i + 1])
						cnt++;
				}
				if (i % WIDTH != 0) {
					if (val == box_er_fruit_value[i - 1]
							&& box_er_layer_value[i - 1] < 3)
						cnt++;
				}
				if (i < TOTAL - WIDTH) {
					if (val == box_er_fruit_value[i + WIDTH]
							&& box_er_layer_value[i + WIDTH] < 3)
						cnt++;
				}
				if (cnt >= 2)
					return false;
			}
			if (11 <= val)
				return false;

		}
		return true;
	}

	private void phakaPuron() {
		// TODO Auto-generated method stub
		Random r = new Random();
		for (int i = 0; i < TOTAL - WIDTH; i++) {
			if (i < WIDTH) {
				if (box_er_fruit_value[i] == EMPTY_FRUITE_VALUE) {
					box_er_fruit_value[i] = (byte) r.nextInt(TOTAL_FRUITES);
				}
			}
			if (box_er_fruit_value[i + WIDTH] == EMPTY_FRUITE_VALUE) {
				if (box_er_fruit_value[i] == -1 || box_er_layer_value[i] > 2) {
					box_er_fruit_value[i + WIDTH] = (byte) r
							.nextInt(TOTAL_FRUITES);
				} else {
					box_er_fruit_value[i + WIDTH] = box_er_fruit_value[i];
					box_er_fruit_value[i] = (byte) EMPTY_FRUITE_VALUE;

				}
			}
		}
	}

	private void pausePanelDrawing(Graphics g) {
		// TODO Auto-generated method stub

		int yy = 300;
		g.setColor(Color.red);
		g.setFont(new Font("Arial", Font.BOLD + Font.PLAIN, 40));

		FontMetrics ff = g.getFontMetrics();

		String ss = new String("PAUSED");
		g.setColor(Color.WHITE);
		g.drawString(ss, Main.SCR_WIDTH / 2 - ff.stringWidth(ss) / 2, yy);

	}

	private void informationShowing(Graphics g) {
		// TODO Auto-generated method stub

		int rectWidth = 600, rectHeight = 400;
		int Line_GAP = 50;

		int x = Main.SCR_WIDTH / 2 - rectWidth / 2;
		int y = Main.SCR_HEIGHT / 2 - rectHeight / 2;

		g.setColor(Color.WHITE);
		g.fillRect(x, y, rectWidth, rectHeight);

		g.setColor(Color.BLACK);
		g.setFont(new Font("Arial", Font.BOLD + Font.PLAIN, 35));
		FontMetrics ff = g.getFontMetrics();

		int length = infoVector.size();
		y = y + (length * 50) / 2;
		String nowString = new String();

		for (int i = 0; i < length; i++) {
			nowString = infoVector.elementAt(i);

			g.drawString(nowString,
					x + rectWidth / 2 - ff.stringWidth(nowString) / 2,
					y += Line_GAP);

		}

	}

	private void mapShow(Graphics g) {
		// TODO Auto-generated method stub
		int pos;
		byte colourValue;

		g.setColor(Color.BLACK);
		for (int i = 0; i < HEIGHT; i++) {
			for (int j = 0; j < WIDTH; j++) {
				pos = i * WIDTH + j;
				colourValue = box_er_layer_value[pos];
				if (colourValue == -1) {
					g.setColor(Color.BLACK);
				} else if (colourValue == 0) {
					g.setColor(Color.LIGHT_GRAY);
				} else if (colourValue == 1) {
					g.setColor(Color.BLUE);
				} else if (colourValue == 2) {
					g.setColor(Color.RED);
				} else if (colourValue == 3) {
					g.setColor(Color.WHITE);
				} else if (colourValue == 4) {
					g.setColor(Color.ORANGE);
				}

				g.fillRect(gx + j * LEN, gy + i * LEN, LEN, LEN);

			}
		}
	}

	private void showSelectedAll(Graphics g) {
		// TODO Auto-generated method stub
		int len = Main.vector.size();
		g.setColor(Color.BLACK);
		for (int i = 0; i < len; i++) {
			int pos = Main.vector.elementAt(i);
			int y = gy + (pos / WIDTH) * LEN;
			int x = gx + (pos % WIDTH) * LEN;
			g.fillRect(x + 20, y + 20, 10, 10);

		}
	}

	public void makeAllFalse() {
		showPlaing = false;
		showPause = false;
		showMap = false;
	}

	private void drawBoxesWithColorAndFruits(Graphics g) {
		// TODO Auto-generated method

		int bnx, bny, pos;
		byte colourValue, fruiteValue;

		g.setColor(Color.BLACK);
		for (int i = 0; i < HEIGHT; i++) {
			for (int j = 0; j < WIDTH; j++) {
				pos = i * WIDTH + j;
				colourValue = box_er_layer_value[pos];
				fruiteValue = box_er_fruit_value[pos];
				bnx = gx + j * LEN;
				bny = gy + i * LEN;
				if (fruiteValue == -1) {
					g.setColor(Color.BLACK);
					g.fillRect(bnx, bny, LEN, LEN);
				} else {
					Graphics2D g2 = (Graphics2D) g;
					g2.drawImage(Main.photo[fruiteValue], bnx, bny, null);
				}
				// System.out.print(fruiteValue + " ");
				if (colourValue != 4) {
					if (colourValue > 0) {
						byte v = 3;
						g.setColor(Color.BLACK);
						g.drawRect(bnx + v, bny + v, 50 - 2 * v, 50 - 2 * v);
					}
					if (colourValue > 2) {
						g.setColor(Color.BLACK);
						byte v = 3;
						g.drawLine(bnx + v, bny + v, bnx + LEN - v, bny + LEN
								- v);
						g.drawLine(bnx + v, bny + LEN - v, bnx + LEN - v, bny
								+ v);
					}
					if (colourValue > 1) {
						g.setColor(Color.BLACK);
						g.drawOval(bnx + LEN / 4, bny + LEN / 4, LEN / 2,
								LEN / 2);
					}
				}

			}
		}

		String sss = new String("LEVEL - " + String.valueOf(Main.Level));

		g.setColor(Color.WHITE);
		g.setFont(new Font("Arial", Font.BOLD + Font.PLAIN, 30));
		FontMetrics ff = g.getFontMetrics();
		int sx = Main.SCR_WIDTH / 2 - ff.stringWidth(sss) / 2;
		int sy = gy - ff.getAscent() - 10;

		g.drawString(sss, sx, sy);

	}

	private void boxErColorValue(int forLevel) {

		moves = Stage.moves[forLevel];

		for (int i = 0; i < TOTAL; i++)
			box_er_layer_value[i] = Stage.lvl[forLevel][i];

		Random r = new Random();
		for (int i = 0; i < TOTAL; i++) {
			if (box_er_layer_value[i] == -1)
				box_er_fruit_value[i] = -1;
			else if (box_er_layer_value[i] == 4) {
				box_er_fruit_value[i] = 9;
			} else
				box_er_fruit_value[i] = (byte) r.nextInt(TOTAL_FRUITES);
		}

	}

	public int haveZeroFruite() {
		// TODO Auto-generated method stub
		int i;
		for (i = 0; i < TOTAL; i++) {
			if (box_er_fruit_value[i] == EMPTY_FRUITE_VALUE) {
				return i;
			}

		}
		return i;
	}

	public void mouseRelease(MouseEvent e) {
		// TODO Auto-generated method stub

		if (!showPlaing && showInfo)
			return;

		int vec_len = Main.vector.size();

		for (int i = 0; i < vec_len; i++) {
			if (box_er_fruit_value[Main.vector.elementAt(i)] == 9) {
				return;
			}
		}

		if (vec_len == 1) {
			selected_1();
		} else if (vec_len == 2) {
			selected_2();
		} else if (vec_len == 3) {
			selected_3();
		} else if (vec_len == 4) {
			selected_4();
		} else if (vec_len == 5) {
			selected_5();
		} else if (vec_len == 6) {
			selected_6();
		} else if (vec_len == 7) {
			selected_7();
		} else if (vec_len >= 8) {
			selected_8();
		}

		Main.vectorKhaliKoro();
		repaint();
	}

	private void selected_8() {
		// TODO Auto-generated method stub
		int len = Main.vector.size();
		int val = box_er_fruit_value[Main.vector.firstElement()];

		for (int i = 0; i < len; i++) {
			changeBoxValueWithLayerUpdate(Main.vector.elementAt(i));
		}

		for (int i = 0; i < TOTAL; i++) {
			if (box_er_fruit_value[i] == val)
				changeBoxValueWithLayerUpdateGiven(i, 11);
		}

		moves--;
	}

	private void selected_7() {
		// TODO Auto-generated method stub

		int len = Main.vector.size();
		int val = box_er_fruit_value[Main.vector.firstElement()];

		for (int i = 0; i < len; i++) {
			changeBoxValueWithLayerUpdate(Main.vector.elementAt(i));
		}

		for (int i = 0; i < TOTAL; i++) {
			if (box_er_fruit_value[i] == val)
				changeBoxValueWithLayerUpdateGiven(i, 12);
		}

		moves--;

	}

	private void selected_6() {
		// TODO Auto-generated method stub

		int len = Main.vector.size();
		for (int i = 0; i < len; i++) {
			changeBoxValueWithLayerUpdate(Main.vector.elementAt(i));
		}
		changeBoxValueWithLayerUpdateGiven(Main.vector.lastElement(), 11);

		moves--;

	}

	private void selected_5() {
		// TODO Auto-generated method stub
		int len = Main.vector.size();
		for (int i = 0; i < len; i++) {
			changeBoxValueWithLayerUpdate(Main.vector.elementAt(i));
		}
		boolean bb = new Random().nextBoolean();
		if (bb)
			changeBoxValueWithLayerUpdateGiven(Main.vector.lastElement(), 13);
		else
			changeBoxValueWithLayerUpdateGiven(Main.vector.lastElement(), 14);
		moves--;

	}

	private void selected_4() {
		// TODO Auto-generated method stub

		int len = Main.vector.size();
		for (int i = 0; i < len; i++) {
			changeBoxValueWithLayerUpdate(Main.vector.elementAt(i));
		}
		changeBoxValueWithLayerUpdateGiven(Main.vector.lastElement(), 12);

		moves--;

	}

	private void selected_3() {
		// TODO Auto-generated method stub

		int len = Main.vector.size();
		for (int i = 0; i < len; i++) {
			changeBoxValueWithLayerUpdate(Main.vector.elementAt(i));
		}
		moves--;
	}

	private void selected_2() {
		// TODO Auto-generated method stub

		int a = Main.vector.elementAt(0);
		int b = Main.vector.elementAt(1);

		byte val1 = box_er_fruit_value[a];
		byte val2 = box_er_fruit_value[b];

		if (val1 != 11 && val2 != 11)
			return;

		if (val1 == 11 && val2 == 11) {

			changeBoxValueWithLayerUpdate(a);
			changeBoxValueWithLayerUpdate(b);

			horizontalLineEnder(a);
			if (Math.abs(a - b) != 1)
				horizontalLineEnder(b);

			verticleLineEnder(a);
			if (Math.abs(a - b) != WIDTH)
				verticleLineEnder(b);

		} else if (val1 == 11) {

			changeBoxValueWithLayerUpdate(a);
			for (int i = 0; i < TOTAL; i++) {
				if (box_er_fruit_value[i] == val2) {
					boxErFruiteValueWiseKajKoro(i);
				}
			}
			moves--;

		} else {
			changeBoxValueWithLayerUpdate(b);
			for (int i = 0; i < TOTAL; i++) {
				if (box_er_fruit_value[i] == val1) {
					boxErFruiteValueWiseKajKoro(i);
				}
			}
			moves--;
		}

	}

	private void selected_1() {
		// TODO Auto-generated method stub

		int pos = Main.vector.firstElement();

		if (box_er_fruit_value[pos] < 12)
			return;

		if (box_er_fruit_value[pos] == 12) {
			bombBlust(pos);
			moves--;
		} else if (box_er_fruit_value[pos] == 13) {
			horizontalLineEnder(Main.vector.firstElement());
			moves--;
		} else if (box_er_fruit_value[pos] == 14) {
			verticleLineEnder(Main.vector.firstElement());
			moves--;
		}

	}

	private void bombBlust(int position) {
		// TODO Auto-generated method stub

		boolean down = position >= TOTAL - WIDTH;
		boolean up = position < WIDTH;
		boolean left = position % WIDTH == 0;
		boolean right = position % WIDTH == WIDTH - 1;

		changeBoxValueWithLayerUpdate(position);

		if (!up) {
			changeBoxValueWithLayerUpdate(position - WIDTH);
		}
		if (!down) {
			changeBoxValueWithLayerUpdate(position + WIDTH);
		}
		if (!left) {
			changeBoxValueWithLayerUpdate(position - 1);
		}
		if (!right) {
			changeBoxValueWithLayerUpdate(position + 1);
		}
		if (!left && !up) {
			changeBoxValueWithLayerUpdate(position - WIDTH - 1);
		}
		if (!left && !down) {
			changeBoxValueWithLayerUpdate(position + WIDTH - 1);

		}
		if (!right && !up) {
			changeBoxValueWithLayerUpdate(position - WIDTH + 1);
		}
		if (!right && !down) {
			changeBoxValueWithLayerUpdate(position + WIDTH + 1);
		}

	}

	private void horizontalLineEnder(int position) {
		// TODO Auto-generated method stub
		int p1 = position;
		changeBoxValueWithLayerUpdate(p1);

		int p = p1;
		while (p % WIDTH != WIDTH - 1) {
			p++;
			changeBoxValueWithLayerUpdate(p);
		}
		p = p1;
		while (p % WIDTH != 0) {
			p--;
			changeBoxValueWithLayerUpdate(p);
		}
	}

	private void verticleLineEnder(int position) {
		// TODO Auto-generated method stub
		int p1 = position;

		changeBoxValueWithLayerUpdate(p1);

		int p = p1;
		while (p >= WIDTH) {
			p -= WIDTH;
			changeBoxValueWithLayerUpdate(p);
		}

		p = p1;
		while (p < TOTAL - WIDTH) {
			p += WIDTH;
			changeBoxValueWithLayerUpdate(p);
		}

	}

	private void boxErFruiteValueWiseKajKoro(int pos) {

		int value = box_er_fruit_value[pos];

		if (value == -1)
			return;

		if (value == 12) {
			bombBlust(pos);
		} else if (value == 13) {
			horizontalLineEnder(pos);
		} else if (value == 14) {
			verticleLineEnder(pos);
		} else {
			changeBoxValueWithLayerUpdate(pos);
		}

	}

	private void changeBoxValueWithLayerUpdate(int pos) {
		// TODO Auto-generated method stub

		if (box_er_layer_value[pos] != -1) {

			if (box_er_layer_value[pos] == 3)
				box_er_fruit_value[pos] = (byte) new Random()
						.nextInt(TOTAL_FRUITES);
			else
				box_er_fruit_value[pos] = EMPTY_FRUITE_VALUE;

			if (box_er_layer_value[pos] == 4) {
				box_er_layer_value[pos] = 0;
			}

			else if (0 < box_er_layer_value[pos])
				box_er_layer_value[pos]--;
		}

	}

	private void changeBoxValueWithLayerUpdateGiven(int pos, int value) {
		// TODO Auto-generated method stub

		if (box_er_layer_value[pos] != -1)
			box_er_fruit_value[pos] = (byte) value;

		if (box_er_layer_value[pos] == 4)
			box_er_layer_value[pos] = 0;

	}

	public void mousedragging(MouseEvent e) {
		// TODO Auto-generated method stub

		if (!showPlaing)
			return;
		if (showInfo)
			return;

		int x = e.getX();
		int y = e.getY();

		Point p = new Point(x, y);
		Rectangle rectangle = new Rectangle(gx, gy, WIDTH * LEN, HEIGHT * LEN);
		if (!rectangle.contains(p)) {
			return;
		}

		x = (x - gx) / LEN;
		y = (y - gy) / LEN;

		if (x >= WIDTH || y >= HEIGHT)
			return;

		int pos = y * WIDTH + x;
		int nowFruiteValue = box_er_fruit_value[pos];
		int nowColorValue = box_er_layer_value[pos];

		if (nowFruiteValue == 9) {
			Main.vectorKhaliKoro();
			return;
		} else if (nowColorValue == 3) {
			Main.vectorKhaliKoro();
			return;
		}

		if (Main.vector.contains(pos)) {
			return;
		} else {
			if (nowFruiteValue != -1)
				Main.vector.add(pos);
		}

		int leng = Main.vector.size();
		if (leng == 0)
			return;

		int firstVectorFruiteValue = box_er_fruit_value[Main.vector
				.firstElement()];

		if (firstVectorFruiteValue == 11) {
			if (leng > 2) {
				Main.vectorKhaliKoro();
				return;
			}
		} else if (firstVectorFruiteValue == 12) {
			if (leng > 1) {
				Main.vectorKhaliKoro();
				return;
			}
		} else if (firstVectorFruiteValue == 13) {
			if (leng > 1) {
				Main.vectorKhaliKoro();
				return;
			}
		} else if (firstVectorFruiteValue == 14) {
			if (leng > 1) {
				Main.vectorKhaliKoro();
				return;
			}
		} else {
			int vv;
			for (int i = 1; i < leng; i++) {
				vv = box_er_fruit_value[Main.vector.elementAt(i)];
				if (11 <= vv && vv <= 14) {
					Main.vectorKhaliKoro();
					return;
				}
			}

			int a, b, c, d;
			for (int i = 1; i < leng; i++) {

				a = Main.vector.elementAt(i - 1);
				b = Main.vector.elementAt(i);

				c = Math.abs(a - b);
				d = box_er_fruit_value[a] - box_er_fruit_value[b];

				if ((c != WIDTH && c != 1) || d != 0) {
					Main.vectorKhaliKoro();
					return;
				}
			}

		}

	}
}
