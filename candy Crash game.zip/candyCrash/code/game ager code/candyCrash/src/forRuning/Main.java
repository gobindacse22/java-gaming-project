package forRuning;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import audio.PlaySound;

public class Main {

	private static JFrame mainFrame;
	public static MainPanel mainPanel;

	public static BufferedImage[] photo = new BufferedImage[15];
	public static Vector<Integer> vector = new Vector<Integer>();

	public static Vector<String> ruleStrings = new Vector<String>();

	public static int SCR_WIDTH, SCR_HEIGHT, Level = 1;

	public static void main(String[] args) {

		MainPanel.foSound = new PlaySound("fo.mid", true);

		makeAllStage();
		readyAllPhoto();
		readyTopLevel();

		makeingRulesVector();

		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();

		SCR_WIDTH = dimension.width;
		SCR_HEIGHT = dimension.height;

		MainPanel.gx = SCR_WIDTH / 2 - (MainPanel.WIDTH * MainPanel.LEN) / 2;
		MainPanel.gy = SCR_HEIGHT / 2 - (MainPanel.HEIGHT * MainPanel.LEN) / 2;

		mainFrame = new JFrame();
		mainFrame.setUndecorated(true);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		mainFrame.setVisible(true);
		mainFrame.setLayout(new GridLayout(1, 1));

		mainPanel = new MainPanel();
		mainFrame.add(mainPanel);

		mainFrame.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub

				int n = e.getKeyCode();

				if (n == KeyEvent.VK_Q) {
					if (MainPanel.showQuit) {
						MainPanel.showQuit = false;
					} else
						MainPanel.showQuit = true;
					mainPanel.repaint();
					return;
				}

				if (MainPanel.showQuit) {
					if (n == KeyEvent.VK_ENTER) {
						if (MainPanel.quitValue == 0) {
							System.exit(0);
						} else {
							MainPanel.showQuit = false;
						}
						mainPanel.repaint();
					} else if (n == KeyEvent.VK_UP || n == KeyEvent.VK_DOWN) {
						if (MainPanel.quitValue == 1)
							MainPanel.quitValue = 0;
						else
							MainPanel.quitValue = 1;
						mainPanel.repaint();
					}
					return;
				}

				if (MainPanel.showInfo) {
					MainPanel.showInfo = false;
					if (MainPanel.info_option == 1) {
						mainPanel.selectRandomLy();
					} else if (MainPanel.info_option == 2) {
						MainPanel.lcSound.stopMusic();
						mainPanel.notunLevelStart();
					} else if (MainPanel.info_option == 3) {
						Level--;
						mainPanel.notunLevelStart();
					} else if (MainPanel.info_option == 4) {

						MainPanel.nlSound = new PlaySound("nl.wav");
					} else if (MainPanel.info_option == 5) {
						MainPanel.llSound.stopMusic();
						Level--;
						mainPanel.notunLevelStart();
					}
					mainPanel.repaint();
					return;
				}

				if (MainPanel.showFirstOpen) {
					MainPanel.showFirstOpen = false;
					mainPanel.makeAllFalse();
					MainPanel.showPlaing = true;
					MainPanel.showInfo = true;
					MainPanel.info_option = 4;
					MainPanel.infoVector.addElement("STARTING");
					MainPanel.infoVector.addElement("LEVEL "
							+ String.valueOf(Main.Level));
					MainPanel.infoVector.addElement("PRESS ANY KEY");

					MainPanel.bgSound = new PlaySound("bg.mid", true);
					MainPanel.foSound.stopMusic();
					mainPanel.ghum(200);
					mainPanel.repaint();
					return;
				}

				if (MainPanel.showPlaing) {
					if (n == KeyEvent.VK_ESCAPE) {
						mainPanel.makeAllFalse();
						MainPanel.showPause = true;
						MainPanel.bgSound.stopMusic();
						mainPanel.repaint();
						return;
					} else if (n == KeyEvent.VK_M) {
						mainPanel.makeAllFalse();
						MainPanel.showMap = true;
						mainPanel.repaint();
						return;
					}
				} else if (MainPanel.showPause) {
					if (n == KeyEvent.VK_ESCAPE) {
						mainPanel.makeAllFalse();
						MainPanel.showPlaing = true;
						MainPanel.bgSound.audio_clip.loop();
						mainPanel.repaint();
						return;
					}
				} else if (MainPanel.showMap) {
					if (n == KeyEvent.VK_M) {
						mainPanel.makeAllFalse();
						MainPanel.showPlaing = true;
						mainPanel.repaint();
						return;
					}
				}

				if (n == KeyEvent.VK_N) {

					for (int i = 0; i < MainPanel.TOTAL; i++) {
						MainPanel.box_er_layer_value[i] = 0;
					}
					mainPanel.repaint();
				}

			}
		});

		mainFrame.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

				mainPanel.mouseRelease(e);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});

		mainFrame.addMouseMotionListener(new MouseMotionListener() {

			@Override
			public void mouseMoved(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseDragged(MouseEvent e) {
				// TODO Auto-generated method stub

				mainPanel.mousedragging(e);
				mainPanel.repaint();
			}
		});

	}

	private static void makeingRulesVector() {
		// TODO Auto-generated method stub

		File ff = new File("resources/rules/rules.txt");

		Scanner sc = null;

		try {
			sc = new Scanner(ff);
		} catch (Exception e) {
			// TODO: handle exception
		}

		while (sc.hasNextLine()) {
			ruleStrings.addElement(sc.nextLine());
		}

	}

	public static void vectorKhaliKoro() {
		// TODO Auto-generated method stub

		vector.removeAllElements();
	}

	private static void readyTopLevel() {
		// TODO Auto-generated method stub

		File ff = new File("D:\\candy\\toplevel\\level.txt");

		Scanner scanner = null;

		try {
			scanner = new Scanner(ff);
			Level = scanner.nextInt();
		} catch (Exception e) {
			// TODO: handle exception
			Level = 1;
		}

	}

	private static void readyAllPhoto() {
		// TODO Auto-generated method stub

		String str = new String("resources/photo/");
		for (int i = 0; i < 15; i++) {
			photo[i] = null;
			try {
				photo[i] = ImageIO.read(new File(str + String.valueOf(i)
						+ ".jpg"));
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}

	private static void makeAllStage() {
		// TODO Auto-generated method stub
		new Stage();

	}

}
