package audio;

import java.applet.Applet;
import java.applet.AudioClip;
import java.net.URL;

import javax.swing.JApplet;

public class PlaySound extends JApplet {

	public boolean loping = false;
	public AudioClip audio_clip;

	public PlaySound(String str) {
		loping = false;
		Th t = new Th(str);
		t.start();
	}

	public PlaySound(String str, boolean tof) {
		loping = tof;
		Th t = new Th(str);
		t.start();

	}

	class Th extends Thread {

		public Th(String str) {
			URL url = getClass().getResource(str);
			audio_clip = Applet.newAudioClip(url);
		}

		public void run() {
			if (audio_clip != null) {
				if (loping)
					audio_clip.loop();
				else
					audio_clip.play();
			}
		}

	}

	public void stopMusic() {

		try {
			audio_clip.stop();
		} catch (Exception e) {
			// TODO: handle exception
		}

	}
}