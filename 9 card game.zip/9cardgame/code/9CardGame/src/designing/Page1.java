package designing;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

import playing.Main;
import woring.CardSpreading;

import needed.Board;
import needed.Musicc;

public class Page1 {

	public static BufferedImage[] images = new BufferedImage[4];
	public static boolean show;

	public static Rectangle startRectangle = new Rectangle(800, 250, 150, 60);
	public static Rectangle closeRectangle = new Rectangle(800, 350, 150, 60);

	public Page1() {

		show = true;
		getPics();

	}

	public static void mc(MouseEvent e) {

		if (startRectangle.contains(e.getPoint())) {
			show = false;
			Board.caset = new Musicc("maf.WAV", true);
			new CardSpreading().start();
			// new SeasonOver(2).start();
			Page2.show = true;
			Main.board.repaint();
		} else if (closeRectangle.contains(e.getPoint())) {
			System.exit(-1);
		}

	}

	private void getPics() {
		// TODO Auto-generated method stub
		for (int i = 0; i < 4; i++) {
			images[i] = null;
			try {
				images[i] = ImageIO.read(new File("resources/pic/big/one/"
						+ String.valueOf(i) + ".jpg"));
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}

	public void doit(Graphics g) {

		g.setColor(Color.WHITE);
		g.setFont(new Font("Arial", Font.BOLD + Font.PLAIN, 30));

		g.fillRect(closeRectangle.x, closeRectangle.y, closeRectangle.width,
				closeRectangle.height);

		g.fillRect(startRectangle.x, startRectangle.y, startRectangle.width,
				startRectangle.height);

		g.setColor(Color.BLACK);

		g.drawString("START", startRectangle.x + 25, startRectangle.y + 40);
		g.drawString("EXIT", closeRectangle.x + 39, closeRectangle.y + 40);

		Graphics2D g2 = (Graphics2D) g;
		for (int i = 0; i < 4; i++) {
			g2.drawImage(images[i], 200 + i * 60, 200 - i * 50, null);
			g2.rotate(0.15);
		}

	}

}
