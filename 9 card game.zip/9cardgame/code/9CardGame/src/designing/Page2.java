package designing;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Vector;

import javax.imageio.ImageIO;


import woring.ChalDao;
import woring.GameOverTask;
import woring.SeasonOver;
import woring.SendCard;
import needed.Player;

public class Page2 {

	public static Vector<Point> allPosition = new Vector<Point>();

	public static BufferedImage[] cardsImages = new BufferedImage[36];
	public static BufferedImage reverseCard;

	public static Vector<Integer> bv0 = new Vector<Integer>();
	public static Vector<Integer> bv1 = new Vector<Integer>();
	public static Vector<Integer> bv2 = new Vector<Integer>();
	public static Vector<Integer> bv3 = new Vector<Integer>();

	public static SendCard sendCard;
	public static GameOverTask gameOverTask;
	
	public static SeasonOver seasonOver;

	public static int C_WIDTH = 80, C_HEIGHT = 120;
	public static int karDeya = 0;
	public static int Bank = 10;

	public static Player p0, p1, p2, p3;

	public static boolean show = false;

	public Page2() {
		gameOverTask = new GameOverTask(8);
		seasonOver = new SeasonOver();
		show = false;
		loadAllPosition();
		loadCardImages();
		readyPlayers();
		sendCard = new SendCard();
	}

	private void readyPlayers() {
		p0 = new Player(0, "JOY");
		p1 = new Player(1, "BOB");
		p2 = new Player(2, "ALICE");
		p3 = new Player(3, "YOU");
	}

	public void doit(Graphics g) {

		drawingAllOnlyPosition(g);
		drawingAllPlayersCard(g);
		drawingAllCodeCards(g);
		transferringCardDrawing(g);
		drawingPlayersNameWithKarChal(g);
		bankErKaj(g);
		gameOverDrawing(g);
		seasonOverDrawing(g);
	}

	private void seasonOverDrawing(Graphics g) {
		// TODO Auto-generated method stub
		seasonOver.doit(g);
	}

	private void gameOverDrawing(Graphics g) {
		// TODO Auto-generated method stub
		gameOverTask.doit(g);
	}

	private void bankErKaj(Graphics g) {
		// TODO Auto-generated method stub

		g.setFont(new Font("Arial", Font.BOLD + Font.PLAIN, 20));
		g.setColor(Color.WHITE);
		FontMetrics ff = g.getFontMetrics();

		int x = 20, y = 20;

		g.drawRect(x, y, 80, 30);
		g.drawString(String.valueOf(p0.Balance),
				x + 40 - ff.stringWidth(String.valueOf(p0.Balance)) / 2, y + 30
						- ff.getAscent() / 2);

		x += 100;

		g.drawRect(x, y, 80, 30);
		g.drawString(String.valueOf(p1.Balance),
				x + 40 - ff.stringWidth(String.valueOf(p1.Balance)) / 2, y + 30
						- ff.getAscent() / 2);

		x += 100;

		g.drawRect(x, y, 80, 30);
		g.drawString(String.valueOf(p2.Balance),
				x + 40 - ff.stringWidth(String.valueOf(p2.Balance)) / 2, y + 30
						- ff.getAscent() / 2);

		x += 100;

		g.drawRect(x, y, 80, 30);
		g.drawString(String.valueOf(p3.Balance),
				x + 40 - ff.stringWidth(String.valueOf(p3.Balance)) / 2, y + 30
						- ff.getAscent() / 2);

		x += 100;

		g.drawRect(x, y, 80, 30);
		g.drawString(String.valueOf(Bank),
				x + 40 - ff.stringWidth(String.valueOf(Bank)) / 2,
				y + 30 - ff.getAscent() / 2);

	}

	private void drawingPlayersNameWithKarChal(Graphics g) {

		g.setFont(new Font("Arial", Font.BOLD + Font.PLAIN, 20));
		Integer[] position = { 40, 140, 230, 340, 435 };

		int y = 80;
		g.setColor(getColorFor(0));
		g.drawString(p0.name, position[0], y);
		g.setColor(getColorFor(1));
		g.drawString(p1.name, position[1], y);
		g.setColor(getColorFor(2));
		g.drawString(p2.name, position[2], y);
		g.setColor(getColorFor(3));
		g.drawString(p3.name, position[3], y);
		g.setColor(Color.WHITE);
		g.drawString("BANK", position[4], y);

	}

	private Color getColorFor(int i) {
		// TODO Auto-generated method stub

		if (!ChalDao.onceStart)
			return Color.WHITE;

		if (Page2.karDeya == i)
			return Color.RED;
		else
			return Color.WHITE;

	}

	private void transferringCardDrawing(Graphics g) {
		// TODO Auto-generated method stub
		sendCard.doit(g);
	}

	private void drawingAllCodeCards(Graphics g) {
		// TODO Auto-generated method stub
		Graphics graphics2d = (Graphics2D) g;

		int p, len;

		len = bv0.size();
		for (int i = 0; i < len; i++) {
			p = bv0.elementAt(i);

			graphics2d.drawImage(cardsImages[p], allPosition.elementAt(p).x,
					allPosition.elementAt(p).y, null);
		}

		len = bv1.size();
		for (int i = 0; i < len; i++) {
			p = bv1.elementAt(i);
			graphics2d.drawImage(cardsImages[p], allPosition.elementAt(p).x,
					allPosition.elementAt(p).y, null);
		}

		len = bv2.size();
		for (int i = 0; i < len; i++) {
			p = bv2.elementAt(i);
			graphics2d.drawImage(cardsImages[p], allPosition.elementAt(p).x,
					allPosition.elementAt(p).y, null);
		}

		len = bv3.size();
		for (int i = 0; i < len; i++) {
			p = bv3.elementAt(i);
			graphics2d.drawImage(cardsImages[p], allPosition.elementAt(p).x,
					allPosition.elementAt(p).y, null);
		}

	}

	private void drawingAllPlayersCard(Graphics g) {
		// TODO Auto-generated method stub

		Graphics graphics2d = (Graphics2D) g;

		// age reverse card er jaigai cilo
		// (cardsImages[p0.cardAce.elementAt(i)])
		// per person 0 1 2 3 vary korbe mane p1 p2 p0

		int len = p0.cardAce.size();
		for (int i = 0; i < len; i++) {
			graphics2d.drawImage(reverseCard, p0.cardPosition.get(i).x,
					p0.cardPosition.get(i).y, null);
		}

		len = p1.cardAce.size();
		for (int i = 0; i < len; i++) {
			graphics2d.drawImage(reverseCard, p1.cardPosition.get(i).x,
					p1.cardPosition.get(i).y, null);
		}

		len = p2.cardAce.size();
		for (int i = 0; i < len; i++) {
			graphics2d.drawImage(reverseCard, p2.cardPosition.get(i).x,
					p2.cardPosition.get(i).y, null);
		}

		len = p3.cardAce.size();
		for (int i = 0; i < len; i++) {
			graphics2d.drawImage(cardsImages[p3.cardAce.elementAt(i)],
					p3.cardPosition.get(i).x, p3.cardPosition.get(i).y, null);
		}

	}

	private void drawingAllOnlyPosition(Graphics g) {
		// TODO Auto-generated method stub

		int len = allPosition.size();

		g.setColor(Color.WHITE);
		for (int i = 0; i < len; i++) {
			g.drawRect(allPosition.elementAt(i).x, allPosition.elementAt(i).y,
					C_WIDTH, C_HEIGHT);
		}

	}

	private void loadAllPosition() {
		// TODO Auto-generated method stub

		int by = 100;
		int bx = 520;

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 9; j++) {
				allPosition.add(new Point(bx + j * 80, by + i * 120));
			}
		}

	}

	private void loadCardImages() {
		// TODO Auto-generated method stub

		reverseCard = null;
		try {
			reverseCard = ImageIO.read(new File("resources/pic/reverse/4.jpg"));
		} catch (Exception e) {
			// TODO: handle exception
		}

		for (int i = 0; i < 36; i++) {
			cardsImages[i] = null;
			try {
				cardsImages[i] = ImageIO.read(new File("resources/pic/cards/"
						+ String.valueOf(i) + ".jpg"));
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}

}
