package needed;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;
import designing.Page1;
import designing.Page2;

public class Board extends JPanel {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static Musicc caset ;
	
	public static Page1 page1;
	public static Page2 page2;
	
	

	public static int seasonCounter =0;

	public Board() {
		super();
		setBackground(Color.BLACK);
		getAllPages();

		System.out.println("gobindas");
	}

	private void getAllPages() {
		// TODO Auto-generated method stub
		page1 = new Page1();
		page2 = new Page2();
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		if (Page1.show) {
			page1.doit(g);
		} else if (Page2.show) {
			page2.doit(g);
		}

	}

}
