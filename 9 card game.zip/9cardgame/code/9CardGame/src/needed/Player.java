package needed;

import java.awt.Point;
import java.util.Vector;

import designing.Page2;

public class Player {

	public int NUMBER, Balance;
	public String name;
	public Vector<Integer> cardAce = new Vector<Integer>();
	public Vector<Point> cardPosition = new Vector<Point>();

	public Player(int i, String nam) {
		Balance = 50;
		NUMBER = i;
		name = nam;
		getCardPosition();
		if(cardAce.size()!=0)
			cardAce.removeAllElements();
	}

	private void getCardPosition() {
		// TODO Auto-generated method stub
		int start = 0;
		int by = 100;

		if (NUMBER == 0)
			start = 20;
		else if (NUMBER == 1)
			start = 120;
		else if (NUMBER == 2)
			start = 220;
		else
			start = 320;

		for (int i = 0; i < 9; i++) {
			cardPosition.add(new Point(start, by));
			by += Page2.C_HEIGHT / 2;
		}

	}

	public boolean selectPossibleCard() {

		return false;
	}

}
