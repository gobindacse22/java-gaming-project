package needed;

import java.applet.Applet;
import java.applet.AudioClip;
import java.net.URL;

import javax.swing.JApplet;

public class Musicc extends JApplet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public AudioClip audio_clip;
	private boolean longLusting;

	public Musicc(String str, boolean tof) {
		URL url = getClass().getResource(str);
		audio_clip = Applet.newAudioClip(url);
		longLusting = tof;

		new Th().start();
	}

	class Th extends Thread {

		public Th() {

		}

		public void run() {
			if (audio_clip != null) {
				if (longLusting) {
					audio_clip.loop();
				} else {
					audio_clip.play();
				}
			}
		}

	}

	public void stopMusic() {
		// TODO Auto-generated method stub
		if (audio_clip != null)
			audio_clip.stop();
	}
}