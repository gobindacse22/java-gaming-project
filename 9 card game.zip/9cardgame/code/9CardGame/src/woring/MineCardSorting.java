package woring;

import playing.Main;
import designing.Page2;

public class MineCardSorting extends Thread {

	public MineCardSorting() {

		ghum(1000);

	} 

	public void run() {

		int len = Page2.p3.cardAce.size();
		for (int i = 0; i < len; i++) {
			for (int j = 0; j < len; j++) {
				int c = Page2.p3.cardAce.get(i);
				int d = Page2.p3.cardAce.get(j);
				if (c < d) {
					Page2.p3.cardAce.remove(i);
					Page2.p3.cardAce.add(i, d);
					Page2.p3.cardAce.remove(j);
					Page2.p3.cardAce.add(j, c);
				}
			}
		}
		ghum(1000);
		Main.board.repaint();

		new ChalDao().start();

	}

	private void ghum(int i) {
		try {
			Thread.sleep(i);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
