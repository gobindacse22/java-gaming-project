package woring;

import java.util.Random;
import java.util.Vector;

import playing.Main;

import designing.Page2;
import needed.Board;

public class CardSpreading extends Thread {

	public static boolean isWorking = false;

	public CardSpreading() {

		isWorking = true;
		sobarHateCardSunnoKoreDilam();

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		Vector<Integer> suffleCard = new Vector<Integer>();
		Random random = new Random();
		int now;
		while (suffleCard.size() != 36) {
			now = random.nextInt(36);
			if (!suffleCard.contains(now))
				suffleCard.addElement(now);
		}

		int kePabe = 0;
		while (isWorking) {
			if (kePabe == 0) {
				Page2.p0.cardAce.add(suffleCard.firstElement());
				kePabe = 1;
			} else if (kePabe == 1) {
				Page2.p1.cardAce.add(suffleCard.firstElement());
				kePabe = 2;
			} else if (kePabe == 2) {
				Page2.p2.cardAce.add(suffleCard.firstElement());
				kePabe = 3;
			} else if (kePabe == 3) {
				Page2.p3.cardAce.add(suffleCard.firstElement());
				kePabe = 0;
			}
			suffleCard.removeElementAt(0);
			if (suffleCard.size() == 0) {
				isWorking = false;
			}
			ghum(50);
			Main.board.repaint();

		}

		ghum(50);
		Main.board.repaint();
		Board.caset.stopMusic();

		new MineCardSorting().start();

	}

	private void sobarHateCardSunnoKoreDilam() {
		// TODO Auto-generated method stub
		if (Page2.p0.cardAce.size() != 0)
			Page2.p0.cardAce.removeAllElements();
		if (Page2.p1.cardAce.size() != 0)
			Page2.p1.cardAce.removeAllElements();
		if (Page2.p2.cardAce.size() != 0)
			Page2.p2.cardAce.removeAllElements();
		if (Page2.p3.cardAce.size() != 0)
			Page2.p3.cardAce.removeAllElements();
	}

	private void ghum(int i) {
		try {
			Thread.sleep(i);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
