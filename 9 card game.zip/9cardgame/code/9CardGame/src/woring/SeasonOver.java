package woring;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

import needed.Player;

import designing.Page2;

import playing.Main;

public class SeasonOver extends Thread {

	public static boolean show;
	private static String name = new String("YOU ARE");
	public static int person;

	private static String s1 = new String(), s2 = new String();

	public SeasonOver() {
		show = false;
	}

	public SeasonOver(int x) {
		show = true;
		person = x;

		if (x == 0)
			name = "JOY IS";
		else if (x == 1)
			name = "BOB IS";
		else if (x == 2)
			name = "ALICE IS";
		else
			name = "YOU ARE";

	}

	public void doit(Graphics g) {

		if (!show)
			return;
		g.setFont(new Font("Arial", Font.PLAIN, 60));
		FontMetrics ff = g.getFontMetrics();

		int x, y;

		g.setColor(Color.BLACK);
		g.fillRect(0, 0, 1366, 768);

		g.setColor(Color.WHITE);

		x = Main.mainFrame.getWidth() / 2
				- ff.stringWidth("IN THIS TOURNAMENT") / 2;
		y = 200;
		g.drawString("IN THIS TOURNAMENT", x, y);

		x = Main.mainFrame.getWidth() / 2 - ff.stringWidth(name) / 2;
		y = 280;
		g.drawString(name, x, y);

		x = Main.mainFrame.getWidth() / 2 - ff.stringWidth("THE WINNER") / 2;
		y = 360;
		g.drawString("THE WINNER", x, y);

		g.setFont(new Font("Arial", Font.PLAIN, 30));
		ff = g.getFontMetrics();

		x = Main.mainFrame.getWidth() / 2
				- ff.stringWidth("CLICK ANY WHERE TO CONTINE") / 2;
		y = 430;
		g.drawString("CLICK ANY WHERE TO CONTINE", x, y);

		x = Main.mainFrame.getWidth() / 2 - ff.stringWidth(s1) / 2;
		y = 500;
		g.drawString(s1, x, y);

		x = Main.mainFrame.getWidth() / 2 - ff.stringWidth(s2) / 2;
		y = 550;
		g.drawString(s2, x, y);

	}

	public void run() {

		Scanner scn = null;
		String name = new String("");
		int score = 0;

		try {
			scn = new Scanner(new File("resources/files/happy.txt"));
			name = scn.next();
			score = scn.nextInt();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		s1 = "TOP : " + name + " ==> " + String.valueOf(score);
		int tk = 0;
		String namString;
		if (person == 0) {
			namString = new String("JOY");
			tk = Page2.p0.Balance;
		} else if (person == 1) {
			namString = new String("BOB");
			tk = Page2.p1.Balance;
		} else if (person == 2) {
			namString = new String("ALICE");
			tk = Page2.p2.Balance;
		} else {
			namString = new String("YOU");
			tk = Page2.p3.Balance;
		}

		s2 = "NOW: " + namString + " ==> " + String.valueOf(tk);

		if (tk > score) {
			Formatter ff;
			try {
				ff = new Formatter(new File("resources/files/happy.txt"));
				ff.format("%s:", namString);
				ff.format(" %s", String.valueOf(tk));
				ff.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		Main.board.repaint();

		Page2.p0 = new Player(0, "JOY");
		Page2.p1 = new Player(1, "BOB");
		Page2.p2 = new Player(2, "ALICE");
		Page2.p3 = new Player(3, "YOU");

		Page2.bv0.removeAllElements();
		Page2.bv1.removeAllElements();
		Page2.bv2.removeAllElements();
		Page2.bv3.removeAllElements();

		Page2.Bank = 10;

	}

}
