package woring;

public class CutPoint extends Thread {

	public int FromPerson, ToPerson;

	public CutPoint() {

	}

	public CutPoint(int fromPerson, int toPerson) {
		FromPerson = fromPerson;
		ToPerson = toPerson;
	}

	public void run() {
		// TODO Auto-generated method stub

	}

}
