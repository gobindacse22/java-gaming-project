package woring;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Random;

import playing.Main;

import designing.Page2;
import needed.Board;
import needed.Musicc;

public class ChalDao extends Thread {

	public static boolean myChal;
	public int karChal;

	public static boolean onceStart;

	public ChalDao() {

		ghum(1000);
		Main.board.repaint();
		onceStart = true;
		karChal = Page2.karDeya;
		myChal = false;

		if (gameOverHoiceKina()) {

			Board.seasonCounter++;
			if (Board.seasonCounter > 4) {
				Board.seasonCounter = 0;
				new SeasonOver(getSeasonWinner()).start();
			} else {
				new GameOverTask().start();
			}
			return;
		}
		boolean ans = false;
		if (karChal == 0) {
			if (!selectCardFor0()) {
				Page2.p0.Balance--;
				Page2.Bank++;
				ans = true;
			}
		}

		else if (karChal == 1) {
			if (!selectCardFor1()) {
				Page2.p1.Balance--;
				Page2.Bank++;
				ans = true;
			}
		}

		else if (karChal == 2) {
			if (!selectCardFor2()) {
				Page2.p2.Balance--;
				Page2.Bank++;
				ans = true;
			}
		} else if (karChal == 3) {
			if (!selectCardFor3()) {
				Page2.p3.Balance--;
				Page2.Bank++;
				ans = true;
			}
		}

		if (ans) {

			ghum(500);
			new Musicc("ton.wav", false);
			ghum(500);

			Page2.karDeya = (Page2.karDeya + 1) % 4;
			new ChalDao().start();
		}

	}

	private int getSeasonWinner() {
		// TODO Auto-generated method stub

		int a = Page2.p0.Balance;
		int b = Page2.p1.Balance;
		int c = Page2.p2.Balance;
		int d = Page2.p3.Balance;

		if (a >= b && a >= c && a >= d)
			return 0;
		if (b >= a && b >= c && b >= d)
			return 1;
		if (c >= a && c >= b && c >= d)
			return 2;
		return 3;

	}

	private boolean gameOverHoiceKina() {
		// TODO Auto-generated method stub

		if (Page2.p0.cardAce.size() == 0)
			return true;
		if (Page2.p1.cardAce.size() == 0)
			return true;
		if (Page2.p2.cardAce.size() == 0)
			return true;
		if (Page2.p3.cardAce.size() == 0)
			return true;

		return false;
	}

	public void run() {

	}

	private boolean selectCardFor3() {
		// TODO Auto-generated method stub

		ArrayList<Integer> nn = new ArrayList<Integer>();

		int len = Page2.p3.cardAce.size(), x;

		for (int i = 0; i < len; i++) {
			x = Page2.p3.cardAce.get(i);
			if (x % 9 == 3) {
				nn.add(x);
			}
		}

		if (Page2.bv0.size() != 0) {
			int m = Page2.bv0.firstElement();
			int n = Page2.bv0.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p3.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p3.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv1.size() != 0) {
			int m = Page2.bv1.firstElement();
			int n = Page2.bv1.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p3.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p3.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv2.size() != 0) {
			int m = Page2.bv2.firstElement();
			int n = Page2.bv2.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p3.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p3.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv3.size() != 0) {
			int m = Page2.bv3.firstElement();
			int n = Page2.bv3.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p3.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p3.cardAce.contains(n))
					nn.add(n);
			}
		}

		len = nn.size();
		if (len != 0) {
			myChal = true;
			return true;
		}

		return false;
	}

	private boolean selectCardFor2() {
		// TODO Auto-generated method stub

		ArrayList<Integer> nn = new ArrayList<Integer>();

		int len = Page2.p2.cardAce.size(), x;

		for (int i = 0; i < len; i++) {
			x = Page2.p2.cardAce.get(i);
			if (x % 9 == 3) {
				nn.add(x);
			}
		}

		if (Page2.bv0.size() != 0) {
			int m = Page2.bv0.firstElement();
			int n = Page2.bv0.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p2.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p2.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv1.size() != 0) {
			int m = Page2.bv1.firstElement();
			int n = Page2.bv1.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p2.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p2.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv2.size() != 0) {
			int m = Page2.bv2.firstElement();
			int n = Page2.bv2.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p2.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p2.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv3.size() != 0) {
			int m = Page2.bv3.firstElement();
			int n = Page2.bv3.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p2.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p2.cardAce.contains(n))
					nn.add(n);
			}
		}

		int value;
		Point from;
		Point to;

		len = nn.size();
		if (len != 0) {

			int pos = new Random().nextInt(len);
			value = nn.get(pos);

			pos = Page2.p2.cardAce.indexOf(value);
			from = new Point(Page2.p2.cardPosition.get(pos).x,
					Page2.p2.cardPosition.get(pos).y);

			to = new Point(Page2.allPosition.get(value).x,
					Page2.allPosition.get(value).y);

			ghum(1000);
			new SendCard(2, value, from, to).start();
			return true;
		}

		return false;
	}

	private boolean selectCardFor1() {
		// TODO Auto-generated method stub

		ArrayList<Integer> nn = new ArrayList<Integer>();

		int len = Page2.p1.cardAce.size(), x;

		for (int i = 0; i < len; i++) {
			x = Page2.p1.cardAce.get(i);
			if (x % 9 == 3) {
				nn.add(x);
			}
		}

		if (Page2.bv0.size() != 0) {
			int m = Page2.bv0.firstElement();
			int n = Page2.bv0.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p1.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p1.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv1.size() != 0) {
			int m = Page2.bv1.firstElement();
			int n = Page2.bv1.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p1.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p1.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv2.size() != 0) {
			int m = Page2.bv2.firstElement();
			int n = Page2.bv2.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p1.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p1.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv3.size() != 0) {
			int m = Page2.bv3.firstElement();
			int n = Page2.bv3.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p1.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p1.cardAce.contains(n))
					nn.add(n);
			}
		}

		int value;
		Point from;
		Point to;

		len = nn.size();
		if (len != 0) {

			int pos = new Random().nextInt(len);
			value = nn.get(pos);

			pos = Page2.p1.cardAce.indexOf(value);
			from = new Point(Page2.p1.cardPosition.get(pos).x,
					Page2.p1.cardPosition.get(pos).y);

			to = new Point(Page2.allPosition.get(value).x,
					Page2.allPosition.get(value).y);

			ghum(1000);
			new SendCard(1, value, from, to).start();
			return true;
		}

		return false;
	}

	private boolean selectCardFor0() {
		// TODO Auto-generated method stub

		ArrayList<Integer> nn = new ArrayList<Integer>();

		int len = Page2.p0.cardAce.size(), x;

		for (int i = 0; i < len; i++) {
			x = Page2.p0.cardAce.get(i);
			if (x % 9 == 3) {
				nn.add(x);
			}
		}

		if (Page2.bv0.size() != 0) {
			int m = Page2.bv0.firstElement();
			int n = Page2.bv0.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p0.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p0.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv1.size() != 0) {
			int m = Page2.bv1.firstElement();
			int n = Page2.bv1.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p0.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p0.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv2.size() != 0) {
			int m = Page2.bv2.firstElement();
			int n = Page2.bv2.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p0.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p0.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv3.size() != 0) {
			int m = Page2.bv3.firstElement();
			int n = Page2.bv3.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p0.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p0.cardAce.contains(n))
					nn.add(n);
			}
		}

		int value;
		Point from;
		Point to;

		len = nn.size();
		if (len != 0) {

			int pos = new Random().nextInt(len);
			value = nn.get(pos);

			pos = Page2.p0.cardAce.indexOf(value);
			from = new Point(Page2.p0.cardPosition.get(pos).x,
					Page2.p0.cardPosition.get(pos).y);

			to = new Point(Page2.allPosition.get(value).x,
					Page2.allPosition.get(value).y);

			ghum(1000);
			new SendCard(0, value, from, to).start();
			return true;
		}

		return false;
	}

	private void ghum(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static ArrayList<Integer> getMineOptions() {
		// TODO Auto-generated method stub

		ArrayList<Integer> nn = new ArrayList<Integer>();

		int len = Page2.p3.cardAce.size(), x;

		for (int i = 0; i < len; i++) {
			x = Page2.p3.cardAce.get(i);
			if (x % 9 == 3) {
				nn.add(x);
			}
		}

		if (Page2.bv0.size() != 0) {
			int m = Page2.bv0.firstElement();
			int n = Page2.bv0.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p3.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p3.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv1.size() != 0) {
			int m = Page2.bv1.firstElement();
			int n = Page2.bv1.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p3.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p3.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv2.size() != 0) {
			int m = Page2.bv2.firstElement();
			int n = Page2.bv2.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p3.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p3.cardAce.contains(n))
					nn.add(n);
			}
		}

		if (Page2.bv3.size() != 0) {
			int m = Page2.bv3.firstElement();
			int n = Page2.bv3.lastElement();
			if (m % 9 != 0) {
				m--;
				if (Page2.p3.cardAce.contains(m)) {
					nn.add(m);
				}
			}
			if (n % 9 != 8) {
				n++;
				if (Page2.p3.cardAce.contains(n))
					nn.add(n);
			}
		}

		return nn;
	}

	public static void amarChalDilam(MouseEvent e) {
		// TODO Auto-generated method stub

		int j = -1;
		int len = Page2.p3.cardAce.size();

		Rectangle rectangle;

		for (int i = 0; i < len; i++) {
			rectangle = new Rectangle(Page2.p3.cardPosition.get(i).x,
					Page2.p3.cardPosition.get(i).y, Page2.C_WIDTH,
					Page2.C_HEIGHT);
			if (rectangle.contains(e.getPoint())) {
				j = i;
			}
		}

		if (j != -1) {
			ArrayList<Integer> pp = getMineOptions();

			Point from;
			Point to;
			int value = Page2.p3.cardAce.get(j);

			if (pp.contains(value)) {

				from = new Point(Page2.p3.cardPosition.get(j).x,
						Page2.p3.cardPosition.get(j).y);
				to = new Point(Page2.allPosition.get(value).x,
						Page2.allPosition.get(value).y);

				new SendCard(3, value, from, to).start();

			}

		}

	}

}
