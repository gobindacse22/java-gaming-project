package woring;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import playing.Main;

import designing.Page2;

public class GameOverTask extends Thread {

	public static int winner;
	public static boolean show;

	public GameOverTask(int xc) {

		show = false;
	}

	public GameOverTask() {
		show = true;
		if (Page2.p0.cardAce.size() == 0)
			winner = 0;
		else if (Page2.p1.cardAce.size() == 0)
			winner = 1;
		else if (Page2.p2.cardAce.size() == 0)
			winner = 2;
		else
			winner = 3;
	}

	public void doit(Graphics g) {

		if (!show)
			return;

		int x = 650, y = 640;

		String name = new String("");
		if (winner == 0)
			name = "JOY IS";
		else if (winner == 1)
			name = "BOB IS";
		else if (winner == 2)
			name = "ALICE IS";
		else
			name = "YOU ARE";

		name = "THIS TIME " + name + " THE WINNER";

		g.setFont(new Font("arial", Font.BOLD + Font.PLAIN, 30));
		g.setColor(Color.WHITE);
		g.drawString(name, x, y);
		x = 700;
		y += 40;
		g.drawString("CLICK TO CONTINUE", x, y);

	}

	private void ghum(int i) {
		// TODO Auto-generated method stub

		try {
			Thread.sleep(i);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void run() {

		Main.board.repaint();
		ghum(1000);
		notunGameSuruHoileKoro();
	}

	private void notunGameSuruHoileKoro() {
		// TODO Auto-generated method stub

		Page2.p0.cardAce.removeAllElements();
		Page2.p1.cardAce.removeAllElements();
		Page2.p2.cardAce.removeAllElements();
		Page2.p3.cardAce.removeAllElements();

		Page2.bv0.removeAllElements();
		Page2.bv1.removeAllElements();
		Page2.bv2.removeAllElements();
		Page2.bv3.removeAllElements();

		int tk = Page2.Bank;

		if (winner == 0)
			Page2.p0.Balance += tk;
		else if (winner == 1)
			Page2.p1.Balance += tk;
		else if (winner == 2)
			Page2.p2.Balance += tk;
		else
			Page2.p3.Balance += tk;

		Page2.Bank = 10;

	}

}
