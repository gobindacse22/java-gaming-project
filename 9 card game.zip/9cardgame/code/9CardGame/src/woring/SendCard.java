package woring;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import playing.Main;
import designing.Page2;

public class SendCard extends Thread {

	private static int CardValue, PersonNumber;
	private static Point From, To;
	public static boolean show;

	public SendCard() {
		show = false;
	}

	public SendCard(int personNmbr, int value, Point from, Point to) {

		PersonNumber = personNmbr;
		CardValue = value;
		From = from;
		To = to;
		show = true;

		cardTaHatThekeBadDeo();
	}

	public void doit(Graphics g) {
		if (!show)
			return;

		Graphics2D g2d = (Graphics2D) g;
		g2d.drawImage(Page2.cardsImages[CardValue], From.x, From.y, null);

	}

	public void run() {

		int r = From.x - To.x, res;

		while (r < 0) {
			res = 5 * ((From.y - To.y) / (r));
			From = new Point(From.x + 5, From.y + res);
			ghum(10);
			Main.board.repaint();
			r = From.x - To.x;
		}

		int m = CardValue / 9;
		int n = CardValue % 9;

		if (m == 0) {
			if (n >= 3) {
				Page2.bv0.addElement(CardValue);
			} else {
				Page2.bv0.add(0, CardValue);
			}
		} else if (m == 1) {
			if (n >= 3) {
				Page2.bv1.addElement(CardValue);
			} else {
				Page2.bv1.add(0, CardValue);
			}
		} else if (m == 2) {
			if (n >= 3) {
				Page2.bv2.addElement(CardValue);
			} else {
				Page2.bv2.add(0, CardValue);
			}
		} else {
			if (n >= 3) {
				Page2.bv3.addElement(CardValue);
			} else {
				Page2.bv3.add(0, CardValue);
			}
		}

		show = false;

		Page2.karDeya = (Page2.karDeya + 1) % 4;
		new ChalDao().start();

	}

	private void cardTaHatThekeBadDeo() {
		// TODO Auto-generated method stub

		if (PersonNumber == 0) {
			Page2.p0.cardAce.removeElement(CardValue);
		} else if (PersonNumber == 1) {
			Page2.p1.cardAce.removeElement(CardValue);
		} else if (PersonNumber == 2) {
			Page2.p2.cardAce.removeElement(CardValue);
		} else {
			Page2.p3.cardAce.removeElement(CardValue);
		}

	}

	public void ghum(int i) {

		try {
			Thread.sleep(i);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
