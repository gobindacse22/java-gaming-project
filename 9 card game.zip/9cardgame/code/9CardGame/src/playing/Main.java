package playing;

import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;

import woring.CardSpreading;
import woring.ChalDao;
import woring.GameOverTask;
import woring.SeasonOver;
import woring.SendCard;

import designing.Page1;
import designing.Page2;
import needed.Board;

public class Main {

	public static JFrame mainFrame;
	public static Board board;

	public static void main(String[] args) {

		board = new Board();

		mainFrame = new JFrame();
		mainFrame.setUndecorated(true);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		mainFrame.setVisible(true);
		mainFrame.setLayout(new GridLayout(1, 1));

		mainFrame.add(board);

		mainFrame.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

				if (SeasonOver.show) {
					SeasonOver.show = false;
					//board = new Board();
					board.repaint();
					new CardSpreading().start();
					return;
				}

				if (GameOverTask.show) {
					GameOverTask.show = false;
					board.repaint();
					new CardSpreading().start();
					return;
				}
				if (Page1.show) {
					Page1.mc(e);
				} else if (Page2.show) {
					if (ChalDao.myChal && !SendCard.show) {
						ChalDao.amarChalDilam(e);
					}
				}
			}
		});

	}

}
